<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<title>Rene Magritte Frame</title>
	</head>
	<body onload="objHoverDiv = document.getElementById('id-hover-div');">
		<img style="text-align: center;" alt="Rene Magritte Frame" width="464px" height="582px" src="./images/rene-magritte-frame.jpg" />
	</body>
	<script type="text/javascript">
					
   		/* ------------------------------------------
	    * ANTI-CLICK-JACKING
	    * ------------------------------------------ */
		/* JavaScript framebuster anti-clickjacking defense
		* for browsers older than IE 8 or Firefox 3.6
		*/
		//if (top.frames.length!=0)top.location=self.document.location;
	</script>
</html>