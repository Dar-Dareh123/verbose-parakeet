---
name: I'm Stuck
about: When you are stuck exploiting a vulnerability
title: ''
labels: ''
assignees: ''

---

Questions here may or may not be answered depending on the state of the question, to increase your chance, read this before asking [Asking For Technical Help](https://digi.ninja/blog/asking_for_help.php).

Basically, the more details you give, the more chance of getting an answer.

Support will only be given for users running the latest pull of code from GitHub. Not a tagged release, not a pre-installed app, not a ZIP you got from a mate.
